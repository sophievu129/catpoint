package com.udacity.catpoint.security.application;

import com.udacity.catpoint.image.service.FakeImageService;
import com.udacity.catpoint.image.service.ImageService;
import com.udacity.catpoint.security.data.PretendDatabaseSecurityRepositoryImpl;
import com.udacity.catpoint.security.data.SecurityRepository;

/**
 * This is the main class that launches the application.
 */
public class CatpointApp {
    public static void main(String[] args) {
        SecurityRepository securityRepository = new PretendDatabaseSecurityRepositoryImpl();
        ImageService imageService = new FakeImageService();
        CatpointGui gui = new CatpointGui(securityRepository, imageService);
        gui.setVisible(true);
    }
}
